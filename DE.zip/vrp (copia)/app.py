from flask import Flask, render_template, request
import random
import math

app = Flask(__name__)

coord = {
    'Jiloyork': (19.916012, -99.580580),
    'Toluca': (19.289165, -99.655697),
    'Atlacomulco': (19.799520, -99.873844),
    'Guadalajara': (20.677754472859146, -103.34625354877137),
    'Monterrey': (25.69161110159454, -100.321838480256),
    'QuintanaRoo': (21.163111924844458, -86.80231502121464),
    'Michohacan': (19.701400113725654, -101.20829680213464),
    'Aguascalientes': (21.87641043660486, -102.26438663286967),
    'CDMX': (19.432713075976878, -99.13318344772986),
    'QRO': (20.59719437542255, -100.38667040246602)
}

def distancia(coord1, coord2):
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    return math.sqrt((lat1 - lat2) ** 2 + (lon1 - lon2) ** 2)

def evalua_ruta(ruta, coord_seleccionadas):
    total = 0
    for i in range(len(ruta) - 1):
        total += distancia(coord_seleccionadas[ruta[i]], coord_seleccionadas[ruta[i + 1]])
    total += distancia(coord_seleccionadas[ruta[-1]], coord_seleccionadas[ruta[0]])
    return total

def i_hill_climbing(coord_seleccionadas):
    ruta = list(coord_seleccionadas.keys())
    mejor_ruta = ruta[:]
    max_iteraciones = 10

    while max_iteraciones > 0:
        random.shuffle(ruta)
        mejora = True

        while mejora:
            mejora = False
            dist_actual = evalua_ruta(ruta, coord_seleccionadas)
            for i in range(len(ruta)):
                for j in range(i + 1, len(ruta)):
                    ruta_tmp = ruta[:]
                    ruta_tmp[i], ruta_tmp[j] = ruta_tmp[j], ruta_tmp[i]
                    dist = evalua_ruta(ruta_tmp, coord_seleccionadas)
                    if dist < dist_actual:
                        ruta = ruta_tmp
                        mejora = True
                        dist_actual = dist
                        break
                if mejora:
                    break

        if evalua_ruta(ruta, coord_seleccionadas) < evalua_ruta(mejor_ruta, coord_seleccionadas):
            mejor_ruta = ruta[:]

        max_iteraciones -= 1

    return mejor_ruta

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        seleccionadas = request.form.getlist("lugares")
        if len(seleccionadas) < 2:
            return render_template("formulario.html", coord=coord, mensaje="Selecciona al menos 2 lugares.")
        
        coord_seleccionadas = {k: coord[k] for k in seleccionadas}
        ruta = i_hill_climbing(coord_seleccionadas)
        distancia_total = round(evalua_ruta(ruta, coord_seleccionadas), 3)
        return render_template("formulario.html", coord=coord, ruta=ruta, distancia=distancia_total)
    
    return render_template("formulario.html", coord=coord)

if __name__ == "__main__":
    app.run(debug=True)
